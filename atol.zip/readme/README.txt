Membuat Website Pembelian Tiket FILM menggunakan PHP dan REST API

1. API FILM (TMDB)
	- Untuk menampilkan FILM yang tersedia dan sedang tayang di bioskop
	- https://api.themoviedb.org/3/discover/movie?api_key=70cdeab72720dc1a144f4d142a9189c6&language=en-US&sort_by=popularity.desc&page=1&primary_release_year=2022&with_original_language=id
	 

2. API 